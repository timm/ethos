
<a name=top></a><p>       

&nbsp;[home](http://git.io/silon) ::
[src](https://github.com/timm/silon/raw/master/src) ::
[issues](http://git.io/silon) ::
<a href="https://github.com/timm/silon/raw/master/raw/master/LICENSE.md">&copy; 2020</a>,
Tim Menzies
<<a href="mailto:timm@ieee.org">timm&commat;ieee.org</a>>
<br>
[<img width=500 src="https://github.com/duo101/flip/raw/master/etc/img/flip.png">](http://git.io/silon)<br>


# Silon


Cluster + contrast + dominate + optimize 


The more you have, the more you are occupied. The less you have, the more free you are.  
-- Mother Teresa

The whole point of getting things done is knowing what to leave undone.  
-- Oswald Chambers

Complexity has nothing to do with intelligence, simplicity does.  
-- Larry Bossidy

The art of being wise is the art of knowing what to overlook.   
-- William James

It is vain to do with more what can be done with less.   
-- William Of Occam


The art of simplicity is a puzzle of complexity.  
-- Doug Horton


Simplicity is the ultimate sophistication.  
-- Leonardo da Vinci

Simplicity is prerequisite for reliability.  
— Edsger W. Dijkstra

Small needs lead to a large life.   
-- Unknown


Simplex sigillum veri   
(Simplicity is the sign of truth.)   
-- Hermann Boerhaave

Less is more.   
-- Dieter Rams

less, plz.    
-- Tim Menzies
