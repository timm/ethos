

```py
from lib  import ok,excursion
from why  import Why
from tab import Tab

@ok
def _div1():
  t = Tab(file = "data/auto93.csv")
  Why(t)
```
