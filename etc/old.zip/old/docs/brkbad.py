```py
import sys
pprint,re,random,traceback,argparse
import sys
from tricks import *

def about(): return  [
"""
Useful routines for building simple data miners and optimizers.
Break up the  data into regions of bad and better.
Report ways to jump between the regions.
""","""
Copyright (c) 2020, Tim Menzies.
All rights reserved under the BSD 2-Clause license.
""",
  # sway
  elp("verbose mode for DIV",        divVerbose= False),
  elp("bin min size =len**b",        b  = 0.5),
  elp("merge bins if score delta below e",  e=0.01),
  elp("coefficient for distance" ,   p  = 2),

  elp("training data (arff format",  train = "train.csv"),
  elp("testing data (csv format)",   test  = "test.csv"),
  # --------------------------------------------------------------------
  # System
  elp("Run some tests.",        t = ""),
  elp("Run all tests. ", T = False)
]


def elp(txt,**d):
  for k in d:
    key = k
    val = d[k]
    break
  default = val[0] if isinstance(val,list)  else val
  if val is False :
    return key,dict(help=txt, action="store_true")
  m,t = "str",str
  if isinstance(default,int)  : m,t= "int",int
  if isinstance(default,float): m,t= "float",float
  if isinstance(val,list):
    return key,dict(help=txt, choices=val,          
                    default=default, metavar=m ,type=t)
  return key,dict(help=txt + ("; e.g. %s" % val), 
                 default=default, metavar=m, type=t)

def args(before, after, *lst):
  parser = argparse.ArgumentParser(epilog=after, description = before,
               formatter_class = argparse.RawDescriptionHelpFormatter)
  for key, args in lst:
    parser.add_argument("-"+key,**args)
  return parser.parse_args()

def rows(x=None):
  prep=lambda z: re.sub(r'([\n\t\r ]|#.*)','',z.strip())
  if x:
    with open(x) as f:
      for y in f: 
         z = prep(y)
         if z: yield z.split(",")
  else:
   for y in sys.stdin: 
         z = prep(y)
         if z: yield z.split(",")

def cols(src):
  todo = None
  for a in src:
    todo = todo or [n for n,s in enumerate(a) if not "?"in s]
    yield [ a[n] for n in todo]
```
```py
class Thing:
  def __repr__(i):
     s = pprint.pformat(has(i.__dict__),compact=True)
     return  re.sub(r"'",' ',s)

def has(i,seen=None):
   seen = seen or {}
   if isinstance(i,Thing)         : 
      if i in seen: return "_"
      seen[i]=i
      return dict(klass=i.__class__.__name__, slots=has(i.__dict__,seen))
   if isinstance(i,(tuple,list)): 
      return [ has(v,seen) for v in i ]
   if isinstance(i,dict): 
      return { k:has(i[k], seen) for k in i if str(k)[0] !="_"}
   return i

def o(i):
  dprint(i.__dict__)

def dprint(d, pre="",skip="_"):
  def q(z):
    if isinstance(z,float): return "%5.3f" % z
    if callable(z): return "f(%s)" % z.__name__
    return str(z)
  l = sorted([(k,d[k]) for k in d if k[0] != skip])
  return pre+'{'+", ".join([('%s=%s' % (k,q(v))) 
                             for k,v in l]) +'}'
```

```py
class Test:
  t,f = 0,0
  all = []
  def score(s): 
    t,f = Test.t, Test.f
    return f"#TEST {s} passes = {t-f} fails = {f}"
  def go(fn=None, use=None):
    if fn:
      Test.all += [fn]
    elif use:
      [Test.run(fn) for fn in Test.all if use in fn.__name__]
    else: 
      [Test.run(fn) for fn in Test.all]
  def run(fun):    
    try:
      Test.t += 1
      print("### ",fun.__name__)
      random.seed(1)
      fun()
      print(Test.score("PASS"),':',fun.__name__)
    except Exception:
      Test.f += 1
      print(traceback.format_exc())
      print(Test.score("FAIL"),':',fun.__name__)

go  = Test.go
```
my = args(*about())

```

```py
def no(s)     : return  s == "?"
def nump(s)   : return "<" in s or "$" in s or ">" in s
def goalp(s)  : return "<" in s or "!" in s or ">" in s
def klassp(s) : return "!" in s
def lessp(s)  : return "<" in s

class Col(Thing):
  def __init__(i,pos,txt):
    i.n, i.pos, i.txt = 0, pos, txt
    i.w = -1 if lessp(txt) else 1
  def __add__(i,x):
    if no(x): return x
    i.n += 1
    return i.add(x)

class Num(Col):
  def __init__(i, *l):
    super().__init__(*l)
    i.mu, i.lo, i.hi = 0, 10**32, -10**32
  def add(i,x):
    x = float(x)
    i.lo,i.hi = min(i.lo,x), max(i.hi,x)
    i.mu      = i.mu + (x - i.mu)/i.n
    return x
  def norm(i,x):
    if no(x) : return x
    return (x - i.lo)  / (i.hi - i.lo + 0.000001)
  def dist(i,x,y):
    if no(x) and no(y): return 1
    if no(x): x = i.lo if y > i.mu else i.hi
    if no(y): y = i.lo if x > i.mu else i.hi
    return abs(i.norm(x) - i.norm(y))

class Sym(Col):
  def __init__(i, *l):
    super().__init__(*l)
    i.seen, i.most, i.mode = {}, 0, None
  def add(i,x):
    tmp = i.seen[x] = i.seen.get(x,0) + 1
    if tmp > i.most: i.most,i.mode = tmp,x
    return x
  def dist(i,x,y): 
    return 1 if no(x) and no(y) else x != y
 
class Cols(Thing):
  def __init__(i) : 
    i.x,i.y,i.nums,i.syms,i.all,i._klass = {},{},{},{},[],None
  def add(i,lst): 
    [ col.add( lst[col.pos] ) for col in i.all ]
  def klass(i,lst): 
    return lst[i._klass]
  def header(i,lst):
    for pos,txt in enumerate(lst):
      tmp = (Num if nump(txt) else Sym)(pos,txt)
      i.all += [tmp]
      (i.y    if goalp(txt) else i.x)[pos] = tmp
      (i.nums if nump(txt)  else i.syms)[pos] = tmp
      if klassp(txt) : i._klass  = tmp

class Tab(Thing):
  def __init__(i,rows=[]):
    i.rows, i.cols = [], Cols()
    [i.add(row) for row in rows]
  def clone(i,rows=[]):
    data = [[c.txt for c in i.cols.all]] + rows
    return Tab(data = data)
  def __add__(i,a): 
    return i.add(a) if i.cols.all else i.cols.header(a)
  def add(i,a): 
    i.rows += [[c + a[c.pos] for c in i.cols.all]]
  def read(i,data=None): 
    [i + row for row in cols(rows(data))]
    return i
  def dist(i,xs,ys,cols=None):
    d,cols = 0, cols or i.cols.x
    for col in cols.values():
      inc = col.dist( xs[col.pos], ys[col.ps] )
      d  += inc**my.p
    return (d/len(cols))**(1/my.p)
  def pairs(i,col):
    return Bins(col.pos,i.rows, lambda z: z[col.pos], 
                                lambda z: i.cols.klass(z))

def syms(i,txt,a,x,y,goal=True):
  ranges={}
  all = Range(txt,goal)
  for one in a:
    x1, y1 = x(one), y(one)
    if no(x1): continue
    if not x1 in ranges: ranges[x1] = Range(txt,goal)
    r = ranges[x]
    r.add(x1,y1)
    all.add(x1,y1)
    r.s(all)
  return all

class Range(Thing):
  def __init__(i,what,want):
    i.what,i.want = what, want
    i.n, i.yes, i.no = 0,0.0001,0.0001
    i._s = 0
  def add(i,x,y):
    i.n += 1
    if y==i.want: i.yes += 1
    else        :  i.no += 1
  def s(i, all):
    yes   = i.yes/all.yes 
    no    = i.no/all.no
    i._s  =  yes**2/(yes+no+0.0001) if yes > no else 0
    return i._s

class DBin(Range):
  def add(i,x,y):
    i.x = x
    super().add(x,y)

class SBin(Range):
  def __init__(i, *lst):
    super().__init__(*lst)
    i.lo, i.hi       = None,None
  def add(i,x,y):
    super().add(x,y)
    i.lo = min(x,i.lo)
    i.hi = max(x,i.hi)
  def merge(i,j):
    k     = SBin(i.what, i.want)
    k.lo  = min(i.lo, j.lo) 
    k.hi  = max(i.hi, j.hi) 
    k.n   = i.n + j.n
    k.no  = i.no  + j.no
    k.yes = i.yes + j.yes
    return k
  def better(c,a,b,all):
    sa, sb, sc = a.s(all), b.s(all), c.s(all)
    return abs(sb - sa) < my.e or sc >= sb and sc >= sa

class Bins(Thing):
  def __init__(i,txt,a,x,y,goal=True, bin=SBin): 
    i.txt  = txt
    i.goal = goal
    i.bin  = bin
    i.all  = i.bin(txt, goal)  
    return i.merge( i.grow( i.pairs(x,y)))
  def pairs(i,x,y,lst):
    lst = [(x(z), y(z)) for z in a if not isinstance(x(z),str)]
    return sorted(lst, key= lambda z:z[0])
  def grow(i,a):
    min  = len(a)**my.b
    use  = len(a) - min
    bins = [i.bin(i.txt,i.goal)]
    for j,(x,y) in enumerate(a):
      if j < use and bins[-1].n > min:
        bins += [i.bin(i.txt,i.goal)]
      bins[-1].add(x,y)
      i.all.add(x,y) 
    return bins
  def merge(i,bins):
    j, tmp = 0, []
    while j < len(bins):
       a = bins[j]
       if j < len(bins) - 1:
          b = bins[j+1]
          c = a.merge(b)
          if c.better(a,b,i.all):
             a = c
             j += 1
       tmp += [a]
       j += 1
    return i.merge(tmp) if len(tmp) < len(bins) else bins
```

```py
@go
def hello(): print(about()[0])

@go
def _hetab1():
  t = Tab().read("data/weather4.csv")
  print(t)

@go
def _tab2():
  t = Tab().read("data/auto93.csv")
  print(t)

#go()

if __name__ == "__main__":
   if my.T: go()
   if my.t: go(use=my.t)
```
