<img src="etc/img/duo.jpg" width=300 align=right>

# DUO: Data Miners Using/Used-by Optimizers

Applications of data miners and optimizers refactored into one
combined toolkit.
